//js/app.js
import './assets/scss/app.scss';

let happy = 5;

console.log('Your JS is working' + happy);

 